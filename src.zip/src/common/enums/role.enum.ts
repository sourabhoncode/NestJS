export enum Role {
    USER = 'USER',
    DRIVER = 'DRIVER',
}
