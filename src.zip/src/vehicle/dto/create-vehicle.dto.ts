export class CreateVehicleDto {
    vehicleNumber: string;
    model: string;
    brand: string;
}
